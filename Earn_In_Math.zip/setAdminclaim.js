const path = require("path");
const admin = require("firebase-admin");

const uid = process.argv[2];
if (!uid) {
  console.log("Usage: node setAdminclaim.js <UID>");
  process.exit(1);
}

// ফাইল মেইন ফোল্ডারে থাকায় পাথ পরিবর্তন করা হলো
const serviceAccount = require(path.resolve(__dirname, "./serviceAccountKey.json"));

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL: "https://earninmath-default-rtdb.firebaseio.com"
});

(async () => {
  try {
    await admin.auth().setCustomUserClaims(uid, { admin: true });
    console.log(`Admin claim set for UID: ${uid}`);
    process.exit(0);
  } catch (error) {
    console.error("Failed:", error);
    process.exit(1);
  }
})();